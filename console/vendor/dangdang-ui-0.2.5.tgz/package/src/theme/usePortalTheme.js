import { useDangdangUI } from "./ThemeContext.js";

function readDocumentTheme() {
    if (typeof document === "undefined") return "light";
    return document.querySelector(".liquid-glass-app.theme-dark, .dd-ui--dark")
        ? "dark"
        : "light";
}

export default function usePortalTheme() {
    const context = useDangdangUI();
    return context.provided
        ? context
        : { ...context, theme: readDocumentTheme() };
}
