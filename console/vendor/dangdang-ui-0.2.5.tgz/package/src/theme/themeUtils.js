import {
    DEFAULT_ACCENT_COLOR,
    DEFAULT_DARK_ACCENT_COLOR,
    DEFAULT_THEME_TOKENS,
    THEME_MODES
} from "./tokens.js";

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
}

function normalizeNumber(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

export function normalizeTheme(value) {
    const normalized = String(value || "light").trim().toLowerCase();
    return THEME_MODES.includes(normalized) ? normalized : "light";
}

export function normalizeHexColor(value, fallback = DEFAULT_ACCENT_COLOR) {
    const input = String(value || "").trim();
    const shortMatch = input.match(/^#([0-9a-f]{3})$/i);
    if (shortMatch) {
        const [r, g, b] = shortMatch[1].split("");
        return `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
    }

    const longMatch = input.match(/^#([0-9a-f]{6})$/i);
    if (longMatch) return `#${longMatch[1].toLowerCase()}`;
    return fallback;
}

function hexToRgb(value) {
    const color = normalizeHexColor(value);
    return {
        r: Number.parseInt(color.slice(1, 3), 16),
        g: Number.parseInt(color.slice(3, 5), 16),
        b: Number.parseInt(color.slice(5, 7), 16)
    };
}

function rgbToHex({ r, g, b }) {
    const channel = value => Math.round(clamp(value, 0, 255)).toString(16).padStart(2, "0");
    return `#${channel(r)}${channel(g)}${channel(b)}`;
}

export function colorLuminance(value) {
    const { r, g, b } = hexToRgb(value);
    const linear = channel => {
        const normalized = channel / 255;
        return normalized <= 0.03928
            ? normalized / 12.92
            : ((normalized + 0.055) / 1.055) ** 2.4;
    };
    return (0.2126 * linear(r)) + (0.7152 * linear(g)) + (0.0722 * linear(b));
}

export function contrastFor(value) {
    return colorLuminance(value) > 0.52 ? "#09090b" : "#ffffff";
}

export function mixHex(first, second, ratio = 0.5) {
    const from = hexToRgb(first);
    const to = hexToRgb(second);
    const amount = clamp(normalizeNumber(ratio, 0.5), 0, 1);
    return rgbToHex({
        r: from.r + ((to.r - from.r) * amount),
        g: from.g + ((to.g - from.g) * amount),
        b: from.b + ((to.b - from.b) * amount)
    });
}

export function deriveDarkAccent(value) {
    const accent = normalizeHexColor(value);
    return colorLuminance(accent) < 0.48
        ? mixHex(accent, "#ffffff", 0.34)
        : accent;
}

export function tokenNameToCssVariable(name) {
    const input = String(name || "").trim();
    if (!input) return "";
    if (input.startsWith("--")) return input;
    const kebab = input
        .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
        .replace(/[\s_]+/g, "-")
        .replace(/-+/g, "-")
        .toLowerCase();
    return `--dd-${kebab}`;
}

export function resolveThemeTokens({
    accentColor = DEFAULT_ACCENT_COLOR,
    darkAccentColor,
    radiusScale = 1,
    glassStrength = 1,
    tokens = {}
} = {}) {
    const accent = normalizeHexColor(accentColor);
    const darkAccent = normalizeHexColor(
        darkAccentColor || deriveDarkAccent(accent),
        DEFAULT_DARK_ACCENT_COLOR
    );
    const radius = clamp(normalizeNumber(radiusScale, 1), 0.6, 1.8);
    const glass = clamp(normalizeNumber(glassStrength, 1), 0, 1.8);
    const resolved = {
        ...DEFAULT_THEME_TOKENS,
        "--dd-color-accent": accent,
        "--dd-color-on-accent": contrastFor(accent),
        "--dd-color-accent-dark": darkAccent,
        "--dd-color-on-accent-dark": contrastFor(darkAccent),
        "--dd-radius-sm": `${Number((10 * radius).toFixed(2))}px`,
        "--dd-radius-md": `${Number((14 * radius).toFixed(2))}px`,
        "--dd-radius-lg": `${Number((20 * radius).toFixed(2))}px`,
        "--dd-radius-xl": `${Number((28 * radius).toFixed(2))}px`,
        "--dd-glass-blur": `${Number((22 * glass).toFixed(2))}px`,
        "--dd-glass-saturation": String(Number((1 + (0.35 * glass)).toFixed(2)))
    };

    Object.entries(tokens || {}).forEach(([name, value]) => {
        const cssVariable = tokenNameToCssVariable(name);
        if (!cssVariable || value === undefined || value === null || value === "") return;
        resolved[cssVariable] = String(value);
    });

    return resolved;
}
