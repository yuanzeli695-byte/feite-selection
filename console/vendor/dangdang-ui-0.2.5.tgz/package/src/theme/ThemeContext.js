import { createContext, createElement, useContext } from "react";

const DEFAULT_THEME_CONTEXT = Object.freeze({
    provided: false,
    theme: "light",
    requestedTheme: "light",
    cssVariables: undefined
});

export const DangdangUIContext = createContext(DEFAULT_THEME_CONTEXT);

export function useDangdangUI() {
    return useContext(DangdangUIContext);
}

export function DangdangThemeBridge({ theme = "light", cssVariables, children }) {
    const resolvedTheme = theme === "dark" ? "dark" : "light";
    return createElement(
        DangdangUIContext.Provider,
        {
            value: {
                provided: true,
                theme: resolvedTheme,
                requestedTheme: resolvedTheme,
                cssVariables
            }
        },
        children
    );
}
