export const DEFAULT_ACCENT_COLOR = "#18181b";
export const DEFAULT_DARK_ACCENT_COLOR = "#f4f4f5";

export const DEFAULT_THEME_TOKENS = Object.freeze({
    "--dd-color-accent": DEFAULT_ACCENT_COLOR,
    "--dd-color-on-accent": "#ffffff",
    "--dd-color-accent-dark": DEFAULT_DARK_ACCENT_COLOR,
    "--dd-color-on-accent-dark": "#09090b",
    "--dd-radius-sm": "10px",
    "--dd-radius-md": "14px",
    "--dd-radius-lg": "20px",
    "--dd-radius-xl": "28px",
    "--dd-radius-full": "999px",
    "--dd-glass-blur": "22px",
    "--dd-glass-saturation": "1.35",
    "--dd-motion-fast": "170ms",
    "--dd-motion-normal": "220ms",
    "--dd-z-modal": "50000",
    "--dd-z-toast": "70000"
});

export const THEME_MODES = Object.freeze(["light", "dark", "system"]);
