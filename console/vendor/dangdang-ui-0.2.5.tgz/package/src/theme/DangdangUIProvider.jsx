import {
    createElement,
    useEffect,
    useMemo,
    useState
} from "react";

import { DangdangUIContext } from "./ThemeContext.js";
import { normalizeTheme, resolveThemeTokens } from "./themeUtils.js";

function systemPrefersDark() {
    return typeof window !== "undefined"
        && typeof window.matchMedia === "function"
        && window.matchMedia("(prefers-color-scheme: dark)").matches;
}

function joinClassNames(...values) {
    return values.filter(Boolean).join(" ");
}

export default function DangdangUIProvider({
    as = "div",
    theme = "light",
    accentColor,
    darkAccentColor,
    radiusScale = 1,
    glassStrength = 1,
    tokens,
    className = "",
    style,
    children,
    ...rest
}) {
    const requestedTheme = normalizeTheme(theme);
    const [systemDark, setSystemDark] = useState(systemPrefersDark);

    useEffect(() => {
        if (requestedTheme !== "system" || typeof window === "undefined" || typeof window.matchMedia !== "function") {
            return undefined;
        }

        const media = window.matchMedia("(prefers-color-scheme: dark)");
        const update = event => setSystemDark(event.matches);
        setSystemDark(media.matches);
        media.addEventListener?.("change", update);
        return () => media.removeEventListener?.("change", update);
    }, [requestedTheme]);

    const resolvedTheme = requestedTheme === "system"
        ? (systemDark ? "dark" : "light")
        : requestedTheme;
    const cssVariables = useMemo(
        () => resolveThemeTokens({ accentColor, darkAccentColor, radiusScale, glassStrength, tokens }),
        [accentColor, darkAccentColor, glassStrength, radiusScale, tokens]
    );
    const contextValue = useMemo(
        () => ({ provided: true, theme: resolvedTheme, requestedTheme, cssVariables }),
        [cssVariables, requestedTheme, resolvedTheme]
    );
    const rootProps = {
        ...rest,
        className: joinClassNames("dd-ui", `dd-ui--${resolvedTheme}`, className),
        "data-dd-theme": resolvedTheme,
        style: { ...cssVariables, ...style }
    };

    return (
        <DangdangUIContext.Provider value={contextValue}>
            {createElement(as, rootProps, children)}
        </DangdangUIContext.Provider>
    );
}
