export default function ModalCloseButton({
    onClick,
    className = "",
    title = "关闭",
    disabled = false,
    ...props
}) {
    return (
        <button
            {...props}
            type="button"
            onClick={onClick}
            disabled={disabled}
            title={title}
            aria-label={title}
            className={`dd-modal-close-button modal-close-button ${className}`.trim()}
        >
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M18 6 6 18M6 6l12 12" />
            </svg>
        </button>
    );
}
