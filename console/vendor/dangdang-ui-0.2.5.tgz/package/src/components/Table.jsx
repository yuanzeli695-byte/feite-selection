import { cn } from "../utils/classNames.js";

export default function Table({ className = "", wrapperClassName = "", children, ...props }) {
    return (
        <div className={cn("dd-table-wrapper", wrapperClassName)}>
            <table {...props} className={cn("dd-table", className)}>{children}</table>
        </div>
    );
}

export function TableHead({ className = "", children, ...props }) {
    return <thead {...props} className={cn("dd-table__head", className)}>{children}</thead>;
}

export function TableBody({ className = "", children, ...props }) {
    return <tbody {...props} className={cn("dd-table__body", className)}>{children}</tbody>;
}

export function TableRow({ selected = false, interactive = false, className = "", children, ...props }) {
    return <tr {...props} className={cn("dd-table__row", selected && "dd-table__row--selected", interactive && "dd-table__row--interactive", className)}>{children}</tr>;
}

export function TableHeader({ align = "left", className = "", children, ...props }) {
    return <th {...props} scope={props.scope || "col"} className={cn("dd-table__header", `dd-table__cell--${align}`, className)}>{children}</th>;
}

export function TableCell({ align = "left", muted = false, className = "", children, ...props }) {
    return <td {...props} className={cn("dd-table__cell", `dd-table__cell--${align}`, muted && "dd-table__cell--muted", className)}>{children}</td>;
}
