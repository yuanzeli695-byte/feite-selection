import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

import { TOAST_DISMISS_EVENT, TOAST_EVENT } from "../notifications.js";
import usePortalTheme from "../theme/usePortalTheme.js";

const TOAST_EXIT_DURATION = 220;

export default function Toast({ target, maxVisible = 5, className = "" }) {
    const [items, setItems] = useState([]);
    const itemsRef = useRef([]);
    const timersRef = useRef(new Set());
    const { theme, cssVariables } = usePortalTheme();

    useEffect(() => {
        itemsRef.current = items;
    }, [items]);

    useEffect(() => {
        const eventTarget = target || (typeof window !== "undefined" ? window : null);
        if (!eventTarget?.addEventListener) return undefined;

        const addTimer = (callback, delay) => {
            const timer = window.setTimeout(() => {
                timersRef.current.delete(timer);
                callback();
            }, delay);
            timersRef.current.add(timer);
        };
        const hideToast = id => {
            setItems(previous => previous.map(item => item.id === id ? { ...item, leaving: true } : item));
            addTimer(() => setItems(previous => previous.filter(item => item.id !== id)), TOAST_EXIT_DURATION);
        };
        const dismissAll = () => {
            const visibleIds = itemsRef.current.filter(item => !item.leaving).map(item => item.id);
            if (!visibleIds.length) return;
            setItems(previous => previous.map(item => visibleIds.includes(item.id) ? { ...item, leaving: true } : item));
            addTimer(
                () => setItems(previous => previous.filter(item => !visibleIds.includes(item.id))),
                TOAST_EXIT_DURATION
            );
        };
        const onToast = event => {
            const item = {
                id: event.detail?.id || `dd-toast-${Date.now()}-${Math.random()}`,
                message: String(event.detail?.message ?? ""),
                type: event.detail?.type || "success",
                duration: Number.isFinite(Number(event.detail?.duration)) ? Number(event.detail.duration) : 2600,
                leaving: false
            };
            setItems(previous => [...previous, item].slice(-Math.max(1, maxVisible)));
            if (item.duration > 0) addTimer(() => hideToast(item.id), item.duration);
        };

        eventTarget.addEventListener(TOAST_EVENT, onToast);
        eventTarget.addEventListener(TOAST_DISMISS_EVENT, dismissAll);
        return () => {
            timersRef.current.forEach(timer => window.clearTimeout(timer));
            timersRef.current.clear();
            eventTarget.removeEventListener(TOAST_EVENT, onToast);
            eventTarget.removeEventListener(TOAST_DISMISS_EVENT, dismissAll);
        };
    }, [maxVisible, target]);

    const toastLayer = (
        <div
            className={`dd-toast-viewport dd-ui--${theme} ${theme === "dark" ? "theme-dark" : ""} ${className}`.trim()}
            data-dd-theme={theme}
            style={cssVariables}
            aria-live="polite"
            aria-atomic="false"
        >
            {items.map(item => (
                <div
                    key={item.id}
                    role={item.type === "error" ? "alert" : "status"}
                    className={`dd-toast dd-toast--${item.type} ${item.leaving ? "dd-toast--leaving toast-leave" : "dd-toast--entering toast-enter"}`}
                >
                    <div className="dd-toast__message">{item.message}</div>
                </div>
            ))}
        </div>
    );

    if (typeof document === "undefined") return toastLayer;
    return createPortal(toastLayer, document.body);
}
