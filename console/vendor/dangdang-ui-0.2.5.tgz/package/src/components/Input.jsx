import { forwardRef, useCallback, useRef } from "react";

import { cn } from "../utils/classNames.js";
import { useFormFieldContext } from "./FormFieldContext.js";

const Input = forwardRef(function Input({
    id,
    size = "md",
    startAdornment,
    endAdornment,
    invalid,
    fullWidth = true,
    className = "",
    inputClassName = "",
    ...props
}, ref) {
    const field = useFormFieldContext();
    const inputRef = useRef(null);
    const resolvedId = id || field?.controlId;
    const resolvedInvalid = invalid ?? field?.invalid ?? false;
    const describedBy = props["aria-describedby"] || field?.describedBy;
    const setInputRef = useCallback(node => {
        inputRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) ref.current = node;
    }, [ref]);

    return (
        <span
            className={cn(
                "dd-input-shell",
                `dd-input-shell--${size}`,
                fullWidth && "dd-input-shell--full",
                resolvedInvalid && "dd-input-shell--invalid",
                props.disabled && "dd-input-shell--disabled",
                className
            )}
            onClick={event => {
                if (props.disabled || event.defaultPrevented) return;
                const interactiveTarget = event.target.closest?.("button, a, input, select, textarea, [role='button'], [tabindex]");
                if (interactiveTarget && interactiveTarget !== inputRef.current) return;
                inputRef.current?.focus();
            }}
        >
            {startAdornment && <span className="dd-input__adornment dd-input__adornment--start">{startAdornment}</span>}
            <input
                {...props}
                ref={setInputRef}
                id={resolvedId}
                required={props.required ?? field?.required ?? undefined}
                aria-invalid={resolvedInvalid || undefined}
                aria-describedby={describedBy}
                className={cn("dd-input", inputClassName)}
            />
            {endAdornment && <span className="dd-input__adornment dd-input__adornment--end">{endAdornment}</span>}
        </span>
    );
});

export default Input;
