import { cloneElement, isValidElement, useEffect, useId, useRef, useState } from "react";

import { cn } from "../utils/classNames.js";

export default function Tooltip({
    content,
    placement = "top",
    disabled = false,
    delay = 120,
    className = "",
    children
}) {
    const [open, setOpen] = useState(false);
    const tooltipId = useId();
    const openTimerRef = useRef(null);
    const show = () => {
        window.clearTimeout(openTimerRef.current);
        openTimerRef.current = window.setTimeout(() => setOpen(true), delay);
    };
    const hide = () => {
        window.clearTimeout(openTimerRef.current);
        setOpen(false);
    };

    useEffect(() => () => window.clearTimeout(openTimerRef.current), []);
    const child = isValidElement(children)
        ? cloneElement(children, {
            "aria-describedby": open ? tooltipId : children.props["aria-describedby"],
            onMouseEnter: event => { children.props.onMouseEnter?.(event); if (!disabled) show(); },
            onMouseLeave: event => { children.props.onMouseLeave?.(event); hide(); },
            onFocus: event => { children.props.onFocus?.(event); if (!disabled) show(); },
            onBlur: event => { children.props.onBlur?.(event); hide(); }
        })
        : <span tabIndex={0} onMouseEnter={show} onMouseLeave={hide} onFocus={show} onBlur={hide}>{children}</span>;

    return (
        <span className={cn("dd-tooltip-anchor", className)}>
            {child}
            {open && !disabled && content && (
                <span id={tooltipId} role="tooltip" className={cn("dd-tooltip", `dd-tooltip--${placement}`)}>{content}</span>
            )}
        </span>
    );
}
