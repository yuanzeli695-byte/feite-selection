import { cn } from "../utils/classNames.js";

function pageItems(page, pageCount, siblingCount) {
    const visible = new Set([1, pageCount]);
    for (let offset = -siblingCount; offset <= siblingCount; offset += 1) {
        const value = page + offset;
        if (value > 1 && value < pageCount) visible.add(value);
    }
    const sorted = [...visible].filter(value => value >= 1 && value <= pageCount).sort((a, b) => a - b);
    const result = [];
    sorted.forEach((value, index) => {
        if (index > 0 && value - sorted[index - 1] > 1) result.push(`ellipsis-${value}`);
        result.push(value);
    });
    return result;
}

export default function Pagination({
    page = 1,
    pageCount,
    total,
    pageSize = 10,
    onChange,
    siblingCount = 1,
    showEdges = true,
    compact = false,
    className = "",
    ariaLabel = "分页"
}) {
    const count = Math.max(1, Number(pageCount) || Math.ceil((Number(total) || 0) / Math.max(1, Number(pageSize) || 10)) || 1);
    const current = Math.max(1, Math.min(count, Number(page) || 1));
    const items = pageItems(current, count, Math.max(0, siblingCount));
    const changePage = next => {
        const normalized = Math.max(1, Math.min(count, next));
        if (normalized !== current) onChange?.(normalized);
    };

    return (
        <nav className={cn("dd-pagination", compact && "dd-pagination--compact", className)} aria-label={ariaLabel}>
            <button type="button" className="dd-pagination__nav" disabled={current <= 1} onClick={() => changePage(current - 1)} aria-label="上一页">
                <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m12.5 5-5 5 5 5" /></svg>
                {!compact && <span>上一页</span>}
            </button>
            {showEdges && items.map(item => typeof item === "number" ? (
                <button
                    type="button"
                    key={item}
                    className={cn("dd-pagination__page", item === current && "dd-pagination__page--active")}
                    aria-current={item === current ? "page" : undefined}
                    onClick={() => changePage(item)}
                >
                    {item}
                </button>
            ) : <span className="dd-pagination__ellipsis" key={item}>…</span>)}
            {!showEdges && <span className="dd-pagination__status">{current} / {count}</span>}
            <button type="button" className="dd-pagination__nav" disabled={current >= count} onClick={() => changePage(current + 1)} aria-label="下一页">
                {!compact && <span>下一页</span>}
                <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m7.5 5 5 5-5 5" /></svg>
            </button>
        </nav>
    );
}
