import { cn } from "../utils/classNames.js";

const DEFAULT_ICONS = {
    success: <path d="m5 12 4 4L19 6" />,
    error: <><path d="M12 8v5" /><path d="M12 16.5v.5" /><circle cx="12" cy="12" r="9" /></>,
    warning: <><path d="M12 9v4" /><path d="M12 17h.01" /><path d="M10.3 3.9 2.6 17.2A2 2 0 0 0 4.3 20h15.4a2 2 0 0 0 1.7-2.8L13.7 3.9a2 2 0 0 0-3.4 0Z" /></>,
    info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5" /><path d="M12 7h.01" /></>
};

export default function Alert({
    type = "info",
    title,
    description,
    icon,
    action,
    closable = false,
    onClose,
    className = "",
    children,
    ...props
}) {
    const role = type === "error" ? "alert" : "status";
    return (
        <div {...props} role={props.role || role} className={cn("dd-alert", `dd-alert--${type}`, className)}>
            {icon !== false && (
                <span className="dd-alert__icon" aria-hidden="true">
                    {icon || <svg viewBox="0 0 24 24">{DEFAULT_ICONS[type] || DEFAULT_ICONS.info}</svg>}
                </span>
            )}
            <div className="dd-alert__content">
                {title && <strong>{title}</strong>}
                {(description || children) && <div>{description || children}</div>}
            </div>
            {action && <div className="dd-alert__action">{action}</div>}
            {closable && (
                <button type="button" className="dd-alert__close" aria-label="关闭提示" onClick={onClose}>
                    <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6 6 8 8M14 6l-8 8" /></svg>
                </button>
            )}
        </div>
    );
}
