import { useEffect, useState } from "react";

export default function RefreshIconButton({
    loading = false,
    onClick,
    title = "刷新",
    sizeClassName = "h-[62px] w-[62px]",
    className = "",
    ...props
}) {
    const [spinning, setSpinning] = useState(false);

    useEffect(() => {
        if (!spinning || typeof window === "undefined") return undefined;
        const timer = window.setTimeout(() => setSpinning(false), 650);
        return () => window.clearTimeout(timer);
    }, [spinning]);

    const handleClick = event => {
        if (loading) return;
        setSpinning(false);
        const schedule = typeof window !== "undefined" && typeof window.requestAnimationFrame === "function"
            ? window.requestAnimationFrame
            : callback => setTimeout(callback, 0);
        schedule(() => setSpinning(true));
        onClick?.(event);
    };

    return (
        <button
            {...props}
            type="button"
            onClick={handleClick}
            disabled={loading}
            title={title}
            aria-label={title}
            aria-busy={loading || undefined}
            className={`dd-refresh-icon-button refresh-icon-button ${sizeClassName} ${className}`.trim()}
        >
            <svg
                viewBox="0 0 24 24"
                className={spinning ? "dd-refresh-icon--spinning refresh-icon-spin-once" : ""}
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
            >
                <path d="M20 11a8 8 0 0 0-14.4-4.8L4 8" />
                <path d="M4 4v4h4" />
                <path d="M4 13a8 8 0 0 0 14.4 4.8L20 16" />
                <path d="M20 20v-4h-4" />
            </svg>
        </button>
    );
}
