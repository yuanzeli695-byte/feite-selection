import { forwardRef } from "react";

import { cn } from "../utils/classNames.js";
import { useFormFieldContext } from "./FormFieldContext.js";

const Textarea = forwardRef(function Textarea({
    id,
    invalid,
    resize = "vertical",
    className = "",
    ...props
}, ref) {
    const field = useFormFieldContext();
    const resolvedInvalid = invalid ?? field?.invalid ?? false;

    return (
        <textarea
            {...props}
            ref={ref}
            id={id || field?.controlId}
            required={props.required ?? field?.required ?? undefined}
            aria-invalid={resolvedInvalid || undefined}
            aria-describedby={props["aria-describedby"] || field?.describedBy}
            className={cn("dd-textarea", resolvedInvalid && "dd-textarea--invalid", `dd-textarea--resize-${resize}`, className)}
        />
    );
});

export default Textarea;
