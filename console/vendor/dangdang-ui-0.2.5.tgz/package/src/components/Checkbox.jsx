import { forwardRef, useEffect, useId, useRef } from "react";

import { cn } from "../utils/classNames.js";

const Checkbox = forwardRef(function Checkbox({
    id,
    label,
    description,
    indeterminate = false,
    className = "",
    ...props
}, forwardedRef) {
    const generatedId = useId();
    const inputRef = useRef(null);
    const resolvedId = id || `dd-checkbox-${generatedId.replace(/:/g, "")}`;

    useEffect(() => {
        if (inputRef.current) inputRef.current.indeterminate = indeterminate;
    }, [indeterminate]);

    const setRefs = node => {
        inputRef.current = node;
        if (typeof forwardedRef === "function") forwardedRef(node);
        else if (forwardedRef) forwardedRef.current = node;
    };

    return (
        <label className={cn("dd-choice", "dd-checkbox", props.disabled && "dd-choice--disabled", className)} htmlFor={resolvedId}>
            <input {...props} ref={setRefs} id={resolvedId} type="checkbox" />
            <span className="dd-choice__control" aria-hidden="true">
                <svg viewBox="0 0 16 16"><path d={indeterminate ? "M4 8h8" : "m3.5 8 3 3 6-6"} /></svg>
            </span>
            {(label || description) && (
                <span className="dd-choice__copy">
                    {label && <b>{label}</b>}
                    {description && <small>{description}</small>}
                </span>
            )}
        </label>
    );
});

export default Checkbox;
