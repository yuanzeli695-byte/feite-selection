import { cn } from "../utils/classNames.js";

export default function Skeleton({
    width,
    height,
    radius,
    variant = "rect",
    lines = 1,
    animated = true,
    className = "",
    style,
    ...props
}) {
    if (variant === "text" && lines > 1) {
        return (
            <span {...props} className={cn("dd-skeleton-stack", className)} aria-hidden="true">
                {Array.from({ length: lines }, (_, index) => (
                    <span
                        key={index}
                        className={cn("dd-skeleton", "dd-skeleton--text", animated && "dd-skeleton--animated")}
                        style={{ width: index === lines - 1 ? "72%" : width, height, borderRadius: radius, ...style }}
                    />
                ))}
            </span>
        );
    }
    return (
        <span
            {...props}
            aria-hidden="true"
            className={cn("dd-skeleton", `dd-skeleton--${variant}`, animated && "dd-skeleton--animated", className)}
            style={{ width, height, borderRadius: radius, ...style }}
        />
    );
}
