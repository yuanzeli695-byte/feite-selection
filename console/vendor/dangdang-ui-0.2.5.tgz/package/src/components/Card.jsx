import { cn } from "../utils/classNames.js";

export default function Card({ as: Component = "div", variant = "raised", interactive = false, className = "", children, ...props }) {
    return <Component {...props} className={cn("dd-card", `dd-card--${variant}`, interactive && "dd-card--interactive", className)}>{children}</Component>;
}

export function CardHeader({ className = "", children, ...props }) {
    return <div {...props} className={cn("dd-card__header", className)}>{children}</div>;
}

export function CardTitle({ as: Component = "h3", className = "", children, ...props }) {
    return <Component {...props} className={cn("dd-card__title", className)}>{children}</Component>;
}

export function CardDescription({ className = "", children, ...props }) {
    return <p {...props} className={cn("dd-card__description", className)}>{children}</p>;
}

export function CardContent({ className = "", children, ...props }) {
    return <div {...props} className={cn("dd-card__content", className)}>{children}</div>;
}

export function CardFooter({ className = "", children, ...props }) {
    return <div {...props} className={cn("dd-card__footer", className)}>{children}</div>;
}
