import { useId } from "react";

import { cn } from "../utils/classNames.js";
import { FormFieldContext } from "./FormFieldContext.js";

export default function FormField({
    id,
    label,
    description,
    hint,
    error,
    required = false,
    optionalLabel = "选填",
    orientation = "vertical",
    className = "",
    children
}) {
    const generatedId = useId();
    const controlId = id || `dd-field-${generatedId.replace(/:/g, "")}`;
    const descriptionId = description ? `${controlId}-description` : undefined;
    const hintId = hint && !error ? `${controlId}-hint` : undefined;
    const errorId = error ? `${controlId}-error` : undefined;
    const describedBy = [descriptionId, hintId, errorId].filter(Boolean).join(" ") || undefined;

    return (
        <FormFieldContext.Provider value={{ controlId, describedBy, invalid: Boolean(error), required }}>
            <div className={cn("dd-form-field", `dd-form-field--${orientation}`, error && "dd-form-field--invalid", className)}>
                {(label || description) && (
                    <div className="dd-form-field__heading">
                        {label && (
                            <label className="dd-form-field__label" htmlFor={controlId}>
                                {label}
                                {required ? <span aria-hidden="true">*</span> : optionalLabel && <small>{optionalLabel}</small>}
                            </label>
                        )}
                        {description && <p id={descriptionId} className="dd-form-field__description">{description}</p>}
                    </div>
                )}
                <div className="dd-form-field__control">{children}</div>
                {error ? (
                    <p id={errorId} className="dd-form-field__message dd-form-field__message--error" role="alert">{error}</p>
                ) : hint ? (
                    <p id={hintId} className="dd-form-field__message">{hint}</p>
                ) : null}
            </div>
        </FormFieldContext.Provider>
    );
}
