import { createContext, useContext } from "react";

export const FormFieldContext = createContext(null);

export function useFormFieldContext() {
    return useContext(FormFieldContext);
}
