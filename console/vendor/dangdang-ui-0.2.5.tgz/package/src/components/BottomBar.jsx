import { createPortal } from "react-dom";

import { cn } from "../utils/classNames.js";

export default function BottomBar({
    children,
    portal = false,
    portalContainer,
    position = "fixed",
    align = "center",
    glass = false,
    className = "",
    ...props
}) {
    if (!children) return null;
    const bar = (
        <div {...props} className={cn("dd-bottom-bar-layer", `dd-bottom-bar-layer--${position}`, `dd-bottom-bar-layer--${align}`, className)}>
            <div className={cn("dd-bottom-bar", glass && "dd-bottom-bar--glass")}>{children}</div>
        </div>
    );
    if (!portal || typeof document === "undefined") return bar;
    return createPortal(bar, portalContainer || document.body);
}
