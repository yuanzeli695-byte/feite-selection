import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

import usePortalTheme from "../theme/usePortalTheme.js";

let mountedModalCount = 0;
let previousDocumentOverflow = "";

const FOCUSABLE_SELECTOR = [
    "button:not([disabled])",
    "a[href]",
    "input:not([disabled])",
    "select:not([disabled])",
    "textarea:not([disabled])",
    "[tabindex]:not([tabindex='-1'])"
].join(",");

function joinClassNames(...values) {
    return values.filter(Boolean).join(" ");
}

export default function Modal({
    open,
    onClose,
    children,
    overlayClassName = "",
    panelClassName = "",
    closeOnBackdrop = true,
    closeOnEscape = true,
    ariaLabel = "对话框",
    ariaLabelledBy,
    portalContainer,
    closeDuration = 190
}) {
    const [mounted, setMounted] = useState(Boolean(open));
    const [closing, setClosing] = useState(false);
    const [visibleChildren, setVisibleChildren] = useState(children);
    const closeTimerRef = useRef(null);
    const backdropPointerDownRef = useRef(false);
    const panelRef = useRef(null);
    const previousActiveElementRef = useRef(null);
    const onCloseRef = useRef(onClose);
    const { theme, cssVariables } = usePortalTheme();

    useEffect(() => {
        onCloseRef.current = onClose;
    }, [onClose]);

    useEffect(() => {
        if (open) setVisibleChildren(children);
    }, [children, open]);

    useEffect(() => {
        if (open) {
            if (closeTimerRef.current && typeof window !== "undefined") window.clearTimeout(closeTimerRef.current);
            setMounted(true);
            setClosing(false);
            return undefined;
        }

        if (!mounted || typeof window === "undefined") return undefined;
        setClosing(true);
        closeTimerRef.current = window.setTimeout(() => {
            setMounted(false);
            setClosing(false);
        }, closeDuration);

        return () => {
            if (closeTimerRef.current) window.clearTimeout(closeTimerRef.current);
        };
    }, [closeDuration, mounted, open]);

    useEffect(() => {
        if (!mounted || typeof document === "undefined") return undefined;
        const root = (portalContainer?.ownerDocument || document).documentElement;
        if (mountedModalCount++ === 0) {
            previousDocumentOverflow = root.style.overflow;
            root.style.overflow = "hidden";
        }
        return () => {
            mountedModalCount -= 1;
            if (mountedModalCount === 0) root.style.overflow = previousDocumentOverflow;
        };
    }, [mounted, portalContainer]);

    useEffect(() => {
        if (!open || !mounted || typeof document === "undefined") return undefined;

        previousActiveElementRef.current = document.activeElement;
        const focusInitial = window.setTimeout(() => {
            const firstFocusable = panelRef.current?.querySelector(FOCUSABLE_SELECTOR);
            (firstFocusable || panelRef.current)?.focus?.();
        }, 0);
        const handleKeyDown = event => {
            if (event.key === "Escape" && closeOnEscape) {
                event.preventDefault();
                onCloseRef.current?.();
                return;
            }
            if (event.key !== "Tab") return;

            const focusable = Array.from(panelRef.current?.querySelectorAll(FOCUSABLE_SELECTOR) || [])
                .filter(element => !element.hidden && element.getAttribute("aria-hidden") !== "true");
            if (!focusable.length) {
                event.preventDefault();
                panelRef.current?.focus?.();
                return;
            }

            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        };

        document.addEventListener("keydown", handleKeyDown, true);
        return () => {
            window.clearTimeout(focusInitial);
            document.removeEventListener("keydown", handleKeyDown, true);
            if (previousActiveElementRef.current?.isConnected) {
                previousActiveElementRef.current?.focus?.();
            }
        };
    }, [closeOnEscape, mounted, open]);

    if (!mounted) return null;

    const modal = (
        <div
            className={joinClassNames(
                "dd-modal-overlay",
                "app-modal-overlay",
                closing && "dd-modal-overlay--closing app-modal-overlay-closing",
                overlayClassName
            )}
            onMouseDown={event => {
                backdropPointerDownRef.current = event.target === event.currentTarget;
            }}
            onClick={event => {
                if (!closeOnBackdrop || event.target !== event.currentTarget || !backdropPointerDownRef.current) {
                    backdropPointerDownRef.current = false;
                    return;
                }

                const selection = typeof window !== "undefined" ? window.getSelection?.()?.toString?.() : "";
                backdropPointerDownRef.current = false;
                if (selection) return;
                onCloseRef.current?.();
            }}
        >
            <div
                className={joinClassNames(
                    "dd-theme-scope",
                    `dd-ui--${theme}`,
                    theme === "dark" && "theme-dark",
                    "contents"
                )}
                data-dd-theme={theme}
                data-modal-theme-scope="true"
                style={cssVariables}
            >
                <div
                    ref={panelRef}
                    role="dialog"
                    aria-modal="true"
                    aria-label={ariaLabelledBy ? undefined : ariaLabel}
                    aria-labelledby={ariaLabelledBy}
                    tabIndex={-1}
                    className={joinClassNames(
                        "dd-modal-panel",
                        "app-modal-panel",
                        closing && "dd-modal-panel--closing app-modal-panel-closing",
                        panelClassName
                    )}
                >
                    {open ? children : visibleChildren}
                </div>
            </div>
        </div>
    );

    if (typeof document === "undefined") return modal;
    return createPortal(modal, portalContainer || document.body);
}
