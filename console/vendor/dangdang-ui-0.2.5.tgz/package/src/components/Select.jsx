import { forwardRef, useCallback, useRef } from "react";

import { cn } from "../utils/classNames.js";
import { useFormFieldContext } from "./FormFieldContext.js";

const Select = forwardRef(function Select({
    id,
    options = [],
    placeholder,
    invalid,
    size = "md",
    className = "",
    children,
    ...props
}, ref) {
    const field = useFormFieldContext();
    const selectRef = useRef(null);
    const resolvedInvalid = invalid ?? field?.invalid ?? false;
    const setSelectRef = useCallback(node => {
        selectRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) ref.current = node;
    }, [ref]);

    return (
        <span
            className={cn("dd-select-shell", `dd-select-shell--${size}`, resolvedInvalid && "dd-select-shell--invalid", props.disabled && "dd-select-shell--disabled", className)}
            onClick={event => {
                if (props.disabled || event.defaultPrevented) return;
                const interactiveTarget = event.target.closest?.("button, a, input, select, textarea, [role='button'], [tabindex]");
                if (interactiveTarget && interactiveTarget !== selectRef.current) return;
                selectRef.current?.focus();
            }}
        >
            <select
                {...props}
                ref={setSelectRef}
                id={id || field?.controlId}
                required={props.required ?? field?.required ?? undefined}
                aria-invalid={resolvedInvalid || undefined}
                aria-describedby={props["aria-describedby"] || field?.describedBy}
                className="dd-select"
            >
                {placeholder !== undefined && <option value="" disabled>{placeholder}</option>}
                {children || options.map(option => (
                    <option key={String(option.value)} value={option.value} disabled={option.disabled}>
                        {option.label}
                    </option>
                ))}
            </select>
            <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6 8 4 4 4-4" /></svg>
        </span>
    );
});

export default Select;
