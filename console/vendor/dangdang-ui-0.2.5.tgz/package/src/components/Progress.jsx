import { cn } from "../utils/classNames.js";

export default function Progress({
    value,
    max = 100,
    label,
    showValue = false,
    formatValue = current => `${Math.round(current)}%`,
    size = "md",
    status = "default",
    indeterminate = false,
    className = "",
    ...props
}) {
    const maximum = Math.max(1, Number(max) || 100);
    const numericValue = Number(value);
    const percent = indeterminate || !Number.isFinite(numericValue)
        ? 0
        : Math.max(0, Math.min(100, (numericValue / maximum) * 100));
    const displayValue = formatValue(percent);

    return (
        <div className={cn("dd-progress-field", className)}>
            {(label || showValue) && (
                <div className="dd-progress-field__heading">
                    {label && <span>{label}</span>}
                    {showValue && <strong>{indeterminate ? "进行中" : displayValue}</strong>}
                </div>
            )}
            <div
                {...props}
                role="progressbar"
                aria-label={props["aria-label"] || (typeof label === "string" ? label : "进度")}
                aria-valuemin={0}
                aria-valuemax={maximum}
                aria-valuenow={indeterminate ? undefined : Math.max(0, Math.min(maximum, numericValue || 0))}
                aria-valuetext={indeterminate ? "进行中" : displayValue}
                className={cn("dd-progress", `dd-progress--${size}`, `dd-progress--${status}`, indeterminate && "dd-progress--indeterminate")}
            >
                <span className="dd-progress__bar" style={{ "--dd-progress-value": `${percent}%` }} />
            </div>
        </div>
    );
}
