import { Children, cloneElement, isValidElement, useMemo, useState } from "react";

import { cn } from "../utils/classNames.js";

function initials(name) {
    const value = String(name || "").trim();
    if (!value) return "?";
    const parts = value.split(/\s+/).filter(Boolean);
    if (parts.length > 1) return `${parts[0][0]}${parts.at(-1)[0]}`.toUpperCase();
    return [...value].slice(0, 2).join("").toUpperCase();
}

export default function Avatar({
    src,
    alt = "",
    name,
    fallback,
    size = "md",
    shape = "circle",
    status,
    className = "",
    ...props
}) {
    const [failed, setFailed] = useState(false);
    const fallbackText = useMemo(() => fallback ?? initials(name || alt), [alt, fallback, name]);
    return (
        <span {...props} className={cn("dd-avatar", `dd-avatar--${size}`, `dd-avatar--${shape}`, className)} aria-label={props["aria-label"] || name || alt || undefined}>
            {src && !failed ? <img src={src} alt={alt} onError={() => setFailed(true)} /> : <span>{fallbackText}</span>}
            {status && <i className={cn("dd-avatar__status", `dd-avatar__status--${status}`)} aria-label={status} />}
        </span>
    );
}

export function AvatarGroup({ max, size = "md", className = "", children, ...props }) {
    const items = Children.toArray(children);
    const visible = max ? items.slice(0, max) : items;
    const overflow = max ? Math.max(0, items.length - max) : 0;
    return (
        <div {...props} className={cn("dd-avatar-group", className)}>
            {visible.map((child, index) => isValidElement(child) ? cloneElement(child, { size: child.props.size || size, key: child.key || index }) : child)}
            {overflow > 0 && <Avatar size={size} fallback={`+${overflow}`} aria-label={`还有 ${overflow} 人`} />}
        </div>
    );
}
