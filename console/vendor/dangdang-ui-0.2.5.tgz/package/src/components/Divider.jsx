import { cn } from "../utils/classNames.js";

export default function Divider({ label, orientation = "horizontal", align = "center", className = "", ...props }) {
    return (
        <div {...props} role="separator" aria-orientation={orientation} className={cn("dd-divider", `dd-divider--${orientation}`, `dd-divider--${align}`, className)}>
            {label && <span>{label}</span>}
        </div>
    );
}
