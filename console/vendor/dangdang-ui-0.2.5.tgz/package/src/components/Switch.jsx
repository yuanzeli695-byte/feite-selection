import { cn } from "../utils/classNames.js";

export default function Switch({
    checked = false,
    onChange,
    label,
    description,
    size = "md",
    disabled = false,
    className = "",
    ...props
}) {
    return (
        <div className={cn("dd-switch-field", disabled && "dd-switch-field--disabled", className)}>
            {(label || description) && (
                <span className="dd-switch-field__copy">
                    {label && <b>{label}</b>}
                    {description && <small>{description}</small>}
                </span>
            )}
            <button
                {...props}
                type="button"
                role="switch"
                aria-checked={checked}
                aria-label={props["aria-label"] || (typeof label === "string" ? label : undefined)}
                disabled={disabled}
                className={cn("dd-switch", `dd-switch--${size}`, checked && "dd-switch--checked")}
                onClick={event => onChange?.(!checked, event)}
            >
                <span className="dd-switch__thumb" />
            </button>
        </div>
    );
}
