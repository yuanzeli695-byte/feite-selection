import { useRef, useState } from "react";

import { cn } from "../utils/classNames.js";
import { optionNavigationIndex, optionTabStopIndex } from "../utils/optionNavigation.js";

export default function SegmentedControl({
    value,
    defaultValue,
    onChange,
    options = [],
    size = "md",
    fullWidth = false,
    disabled = false,
    ariaLabel = "选项切换",
    className = "",
    ...props
}) {
    const [internalValue, setInternalValue] = useState(() => defaultValue ?? options.find(option => !option.disabled)?.value);
    const itemRefs = useRef([]);
    const currentValue = value === undefined ? internalValue : value;
    const activeIndex = Math.max(0, options.findIndex(option => option.value === currentValue));
    const tabStopIndex = optionTabStopIndex(options, currentValue, disabled);

    const activateOption = (option, event) => {
        if (!option || disabled || option.disabled) return;
        if (value === undefined) setInternalValue(option.value);
        onChange?.(option.value, event);
    };

    return (
        <div
            {...props}
            role="radiogroup"
            aria-label={ariaLabel}
            aria-disabled={disabled || undefined}
            className={cn("dd-segmented", `dd-segmented--${size}`, fullWidth && "dd-segmented--full", disabled && "dd-segmented--disabled", className)}
            style={{
                "--dd-segmented-count": Math.max(1, options.length),
                "--dd-segmented-index": activeIndex,
                ...props.style
            }}
        >
            <span className="dd-segmented__thumb" aria-hidden="true" />
            {options.map((option, index) => {
                const selected = option.value === currentValue;
                return (
                    <button
                        key={String(option.value)}
                        ref={node => { itemRefs.current[index] = node; }}
                        type="button"
                        role="radio"
                        aria-checked={selected}
                        disabled={disabled || option.disabled}
                        tabIndex={index === tabStopIndex ? 0 : -1}
                        className={cn("dd-segmented__item", selected && "dd-segmented__item--active")}
                        onClick={event => activateOption(option, event)}
                        onKeyDown={event => {
                            const nextIndex = optionNavigationIndex(options, index, event.key, disabled, true);
                            if (nextIndex < 0) return;
                            event.preventDefault();
                            itemRefs.current[nextIndex]?.focus();
                            activateOption(options[nextIndex], event);
                        }}
                    >
                        {option.icon && <span className="dd-segmented__icon">{option.icon}</span>}
                        <span className="dd-segmented__label">{option.label}</span>
                        {option.badge !== undefined && <small>{option.badge}</small>}
                    </button>
                );
            })}
        </div>
    );
}
