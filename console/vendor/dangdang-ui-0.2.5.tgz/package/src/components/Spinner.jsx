import { cn } from "../utils/classNames.js";

export default function Spinner({ size = "md", label = "加载中", className = "", ...props }) {
    return (
        <span {...props} className={cn("dd-spinner", `dd-spinner--${size}`, className)} role="status" aria-label={label}>
            <span aria-hidden="true" />
        </span>
    );
}
