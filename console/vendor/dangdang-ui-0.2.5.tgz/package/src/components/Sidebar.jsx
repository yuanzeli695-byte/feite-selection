import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef } from "react";

import { cn } from "../utils/classNames.js";

const useIsomorphicLayoutEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;
const SidebarContext = createContext({ collapsed: false, setActiveItem: () => {}, clearActiveItem: () => {} });

export default function Sidebar({
    collapsed = false,
    width = 280,
    collapsedWidth = 82,
    variant = "solid",
    className = "",
    children,
    style,
    ...props
}) {
    const sidebarRef = useRef(null);
    const activeItemRef = useRef(null);
    const syncIndicator = useCallback(() => {
        const sidebar = sidebarRef.current;
        const activeItem = activeItemRef.current;
        if (!sidebar || !activeItem) {
            sidebar?.style.setProperty("--dd-sidebar-indicator-opacity", "0");
            return;
        }
        const sidebarRect = sidebar.getBoundingClientRect();
        const itemRect = activeItem.getBoundingClientRect();
        sidebar.style.setProperty("--dd-sidebar-active-top", `${itemRect.top - sidebarRect.top}px`);
        sidebar.style.setProperty("--dd-sidebar-active-left", `${itemRect.left - sidebarRect.left}px`);
        sidebar.style.setProperty("--dd-sidebar-active-width", `${itemRect.width}px`);
        sidebar.style.setProperty("--dd-sidebar-active-height", `${itemRect.height}px`);
        sidebar.style.setProperty("--dd-sidebar-indicator-opacity", "1");
    }, []);
    const setActiveItem = useCallback(node => {
        activeItemRef.current = node;
        syncIndicator();
    }, [syncIndicator]);
    const clearActiveItem = useCallback(node => {
        if (activeItemRef.current !== node) return;
        activeItemRef.current = null;
        syncIndicator();
    }, [syncIndicator]);
    const contextValue = useMemo(
        () => ({ collapsed, setActiveItem, clearActiveItem }),
        [clearActiveItem, collapsed, setActiveItem]
    );

    useIsomorphicLayoutEffect(syncIndicator);

    useIsomorphicLayoutEffect(() => {
        syncIndicator();
        if (typeof window === "undefined") return undefined;
        const sidebar = sidebarRef.current;
        const resizeObserver = typeof ResizeObserver === "function" && sidebar
            ? new ResizeObserver(syncIndicator)
            : null;
        resizeObserver?.observe(sidebar);
        sidebar?.addEventListener("scroll", syncIndicator, true);
        window.addEventListener("resize", syncIndicator);
        return () => {
            resizeObserver?.disconnect();
            sidebar?.removeEventListener("scroll", syncIndicator, true);
            window.removeEventListener("resize", syncIndicator);
        };
    }, [syncIndicator]);

    return (
        <SidebarContext.Provider value={contextValue}>
            <aside
                {...props}
                ref={sidebarRef}
                className={cn("dd-sidebar", `dd-sidebar--${variant}`, collapsed && "dd-sidebar--collapsed", className)}
                data-collapsed={collapsed || undefined}
                style={{ "--dd-sidebar-width": `${width}px`, "--dd-sidebar-collapsed-width": `${collapsedWidth}px`, ...style }}
            >
                <span className="dd-sidebar__active-indicator" aria-hidden="true" />
                {children}
            </aside>
        </SidebarContext.Provider>
    );
}

export function SidebarHeader({ className = "", children, ...props }) {
    return <div {...props} className={cn("dd-sidebar__header", className)}>{children}</div>;
}

export function SidebarGroup({ label, action, className = "", children, ...props }) {
    const { collapsed } = useContext(SidebarContext);
    return (
        <section {...props} className={cn("dd-sidebar__group", className)}>
            {!collapsed && (label || action) && (
                <div className="dd-sidebar__group-heading">
                    {label && <span>{label}</span>}
                    {action}
                </div>
            )}
            <div className="dd-sidebar__group-items">{children}</div>
        </section>
    );
}

export function SidebarItem({
    active = false,
    icon,
    label,
    description,
    multiline = false,
    badge,
    href,
    className = "",
    children,
    ...props
}) {
    const { collapsed, setActiveItem, clearActiveItem } = useContext(SidebarContext);
    const itemRef = useRef(null);
    const Component = href ? "a" : "button";
    const componentProps = href ? { href } : { type: props.type || "button" };
    const accessibleLabel = typeof label === "string" ? label : undefined;

    useIsomorphicLayoutEffect(() => {
        if (!active) return undefined;
        const item = itemRef.current;
        setActiveItem(item);
        return () => clearActiveItem(item);
    }, [active, clearActiveItem, collapsed, setActiveItem]);

    return (
        <Component
            {...componentProps}
            {...props}
            ref={itemRef}
            className={cn("dd-sidebar-item", active && "dd-sidebar-item--active", multiline && "dd-sidebar-item--multiline", collapsed && "dd-sidebar-item--collapsed", className)}
            aria-current={active ? "page" : undefined}
            aria-label={collapsed ? accessibleLabel : props["aria-label"]}
            title={props.title || (collapsed ? accessibleLabel : typeof description === "string" && !multiline && accessibleLabel ? `${accessibleLabel} · ${description}` : undefined)}
        >
            {icon && <span className="dd-sidebar-item__icon">{icon}</span>}
            {!collapsed && (
                <span className="dd-sidebar-item__copy">
                    <span className="dd-sidebar-item__label">{label || children}</span>
                    {description && multiline && <small>{description}</small>}
                </span>
            )}
            {!collapsed && badge !== undefined && <span className="dd-sidebar-item__badge">{badge}</span>}
        </Component>
    );
}

export function SidebarFooter({ className = "", children, ...props }) {
    return <div {...props} className={cn("dd-sidebar__footer", className)}>{children}</div>;
}
