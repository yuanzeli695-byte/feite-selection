import { useEffect, useId, useRef, useState } from "react";

import { cn } from "../utils/classNames.js";

export default function SearchPill({
    open,
    defaultOpen = false,
    onOpenChange,
    value = "",
    onChange,
    onValueChange,
    onSearch,
    placeholder = "搜索",
    label = "搜索",
    clearable = true,
    disabled = false,
    className = "",
    inputClassName = "",
    ...props
}) {
    const [internalOpen, setInternalOpen] = useState(defaultOpen);
    const inputRef = useRef(null);
    const generatedId = useId();
    const inputId = `dd-search-${generatedId.replace(/:/g, "")}`;
    const isOpen = open === undefined ? internalOpen : open;
    const setOpen = next => {
        if (open === undefined) setInternalOpen(next);
        onOpenChange?.(next);
    };

    useEffect(() => {
        if (isOpen) inputRef.current?.focus();
    }, [isOpen]);

    return (
        <div
            {...props}
            className={cn("dd-search-pill", isOpen && "dd-search-pill--open", disabled && "dd-search-pill--disabled", className)}
            onKeyDown={event => {
                if (event.key === "Escape") {
                    event.preventDefault();
                    setOpen(false);
                }
                props.onKeyDown?.(event);
            }}
        >
            <button type="button" className="dd-search-pill__toggle" aria-label={label} aria-expanded={isOpen} aria-controls={inputId} disabled={disabled} onClick={() => setOpen(!isOpen)}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.2" /><path d="m16 16 4.5 4.5" /></svg>
            </button>
            <input
                ref={inputRef}
                id={inputId}
                value={value}
                disabled={disabled}
                tabIndex={isOpen ? 0 : -1}
                placeholder={placeholder}
                aria-label={label}
                className={cn("dd-search-pill__input", inputClassName)}
                onChange={event => {
                    onChange?.(event);
                    onValueChange?.(event.target.value, event);
                }}
                onKeyDown={event => {
                    if (event.key === "Enter") onSearch?.(value, event);
                }}
            />
            {clearable && value && isOpen && (
                <button type="button" className="dd-search-pill__clear" aria-label="清空搜索" onClick={event => {
                    const syntheticEvent = { ...event, target: { value: "" }, currentTarget: { value: "" } };
                    onChange?.(syntheticEvent);
                    onValueChange?.("", syntheticEvent);
                    inputRef.current?.focus();
                }}>
                    <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6 6 8 8M14 6l-8 8" /></svg>
                </button>
            )}
        </div>
    );
}
