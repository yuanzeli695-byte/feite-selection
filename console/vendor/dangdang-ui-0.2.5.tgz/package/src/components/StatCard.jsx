import Card from "./Card.jsx";
import Badge from "./Badge.jsx";
import { cn } from "../utils/classNames.js";

export default function StatCard({
    label,
    value,
    unit,
    delta,
    deltaType = "neutral",
    description,
    icon,
    sparkline,
    className = "",
    ...props
}) {
    return (
        <Card {...props} className={cn("dd-stat-card", className)}>
            <div className="dd-stat-card__top">
                <span>{label}</span>
                {icon && <i>{icon}</i>}
            </div>
            <div className="dd-stat-card__value">{value}{unit && <small>{unit}</small>}</div>
            <div className="dd-stat-card__bottom">
                {delta !== undefined && <Badge size="sm" variant={deltaType}>{delta}</Badge>}
                {description && <span>{description}</span>}
            </div>
            {sparkline && <div className="dd-stat-card__sparkline">{sparkline}</div>}
        </Card>
    );
}
