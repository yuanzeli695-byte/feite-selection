import { useRef, useState } from "react";

import { cn } from "../utils/classNames.js";
import { optionNavigationIndex, optionTabStopIndex } from "../utils/optionNavigation.js";

export default function Tabs({
    value,
    defaultValue,
    onChange,
    options = [],
    variant = "underline",
    size = "md",
    ariaLabel = "标签页",
    className = "",
    ...props
}) {
    const [internalValue, setInternalValue] = useState(() => defaultValue ?? options.find(option => !option.disabled)?.value);
    const itemRefs = useRef([]);
    const currentValue = value === undefined ? internalValue : value;
    const tabStopIndex = optionTabStopIndex(options, currentValue);

    const activateOption = (option, event) => {
        if (!option || option.disabled) return;
        if (value === undefined) setInternalValue(option.value);
        onChange?.(option.value, event);
    };

    return (
        <div {...props} role="tablist" aria-label={ariaLabel} className={cn("dd-tabs", `dd-tabs--${variant}`, `dd-tabs--${size}`, className)}>
            {options.map((option, index) => {
                const selected = option.value === currentValue;
                return (
                    <button
                        key={String(option.value)}
                        ref={node => { itemRefs.current[index] = node; }}
                        type="button"
                        role="tab"
                        aria-selected={selected}
                        aria-controls={option.controls}
                        id={option.id}
                        disabled={option.disabled}
                        tabIndex={index === tabStopIndex ? 0 : -1}
                        className={cn("dd-tabs__item", selected && "dd-tabs__item--active")}
                        onClick={event => activateOption(option, event)}
                        onKeyDown={event => {
                            const nextIndex = optionNavigationIndex(options, index, event.key);
                            if (nextIndex < 0) return;
                            event.preventDefault();
                            itemRefs.current[nextIndex]?.focus();
                            activateOption(options[nextIndex], event);
                        }}
                    >
                        {option.icon && <span>{option.icon}</span>}
                        {option.label}
                        {option.badge !== undefined && <small>{option.badge}</small>}
                    </button>
                );
            })}
        </div>
    );
}
