import { forwardRef, useId } from "react";

import { cn } from "../utils/classNames.js";

const Radio = forwardRef(function Radio({ id, label, description, className = "", ...props }, ref) {
    const generatedId = useId();
    const resolvedId = id || `dd-radio-${generatedId.replace(/:/g, "")}`;

    return (
        <label className={cn("dd-choice", "dd-radio", props.disabled && "dd-choice--disabled", className)} htmlFor={resolvedId}>
            <input {...props} ref={ref} id={resolvedId} type="radio" />
            <span className="dd-choice__control" aria-hidden="true"><i /></span>
            {(label || description) && (
                <span className="dd-choice__copy">
                    {label && <b>{label}</b>}
                    {description && <small>{description}</small>}
                </span>
            )}
        </label>
    );
});

export default Radio;
