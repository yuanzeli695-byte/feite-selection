function joinClassNames(...values) {
    return values.filter(Boolean).join(" ");
}

export default function Button({
    variant = "primary",
    size = "md",
    loading = false,
    disabled = false,
    fullWidth = false,
    className = "",
    children,
    type = "button",
    ...props
}) {
    return (
        <button
            {...props}
            type={type}
            disabled={disabled || loading}
            aria-busy={loading || undefined}
            className={joinClassNames(
                "dd-button",
                `dd-button--${variant}`,
                `dd-button--${size}`,
                fullWidth && "dd-button--full",
                className
            )}
        >
            {loading && <span className="dd-button__spinner" aria-hidden="true" />}
            <span className="dd-button__content">{children}</span>
        </button>
    );
}
