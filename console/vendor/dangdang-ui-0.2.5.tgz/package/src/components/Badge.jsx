import { cn } from "../utils/classNames.js";

export default function Badge({
    variant = "neutral",
    size = "md",
    dot = false,
    removable = false,
    onRemove,
    className = "",
    children,
    ...props
}) {
    return (
        <span {...props} className={cn("dd-badge", `dd-badge--${variant}`, `dd-badge--${size}`, dot && "dd-badge--dot", className)}>
            {dot && <i aria-hidden="true" />}
            {children}
            {removable && (
                <button type="button" aria-label="移除" onClick={onRemove}>
                    <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m5 5 6 6M11 5l-6 6" /></svg>
                </button>
            )}
        </span>
    );
}
