import { useId, useMemo, useState } from "react";

import { cn } from "../utils/classNames.js";

function numeric(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

export default function Slider({
    id,
    label,
    value,
    defaultValue,
    onChange,
    min = 0,
    max = 100,
    step = 1,
    showValue = true,
    formatValue = current => String(current),
    marks = [],
    disabled = false,
    className = "",
    ...props
}) {
    const generatedId = useId();
    const resolvedId = id || `dd-slider-${generatedId.replace(/:/g, "")}`;
    const [internalValue, setInternalValue] = useState(() => numeric(defaultValue, numeric(min, 0)));
    const currentValue = value === undefined ? internalValue : numeric(value, numeric(min, 0));
    const minimum = numeric(min, 0);
    const maximum = numeric(max, 100);
    const progress = maximum === minimum ? 0 : ((currentValue - minimum) / (maximum - minimum)) * 100;
    const valueText = useMemo(() => formatValue(currentValue), [currentValue, formatValue]);

    return (
        <div className={cn("dd-slider-field", disabled && "dd-slider-field--disabled", className)}>
            {(label || showValue) && (
                <div className="dd-slider-field__heading">
                    {label && <label htmlFor={resolvedId}>{label}</label>}
                    {showValue && <output htmlFor={resolvedId}>{valueText}</output>}
                </div>
            )}
            <input
                {...props}
                id={resolvedId}
                type="range"
                min={minimum}
                max={maximum}
                step={step}
                value={currentValue}
                disabled={disabled}
                aria-valuetext={props["aria-valuetext"] || valueText}
                className="dd-slider"
                style={{ "--dd-slider-progress": `${Math.max(0, Math.min(100, progress))}%`, ...props.style }}
                onChange={event => {
                    const nextValue = Number(event.target.value);
                    if (value === undefined) setInternalValue(nextValue);
                    onChange?.(nextValue, event);
                }}
            />
            {marks.length > 0 && (
                <div className="dd-slider__marks" aria-hidden="true">
                    {marks.map(mark => (
                        <span
                            key={String(mark.value)}
                            style={{ left: `${maximum === minimum ? 0 : ((mark.value - minimum) / (maximum - minimum)) * 100}%` }}
                        >
                            {mark.label}
                        </span>
                    ))}
                </div>
            )}
        </div>
    );
}
