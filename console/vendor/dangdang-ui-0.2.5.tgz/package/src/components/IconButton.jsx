function joinClassNames(...values) {
    return values.filter(Boolean).join(" ");
}

export default function IconButton({
    label,
    title = label,
    variant = "glass",
    size = "md",
    loading = false,
    disabled = false,
    className = "",
    children,
    type = "button",
    ...props
}) {
    return (
        <button
            {...props}
            type={type}
            disabled={disabled || loading}
            title={title}
            aria-label={label || title}
            aria-busy={loading || undefined}
            className={joinClassNames(
                "dd-icon-button",
                `dd-icon-button--${variant}`,
                `dd-icon-button--${size}`,
                className
            )}
        >
            {children}
        </button>
    );
}
