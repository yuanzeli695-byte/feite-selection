export default function EdgeFeather({
    edge = "bottom",
    visible = true,
    position = "fixed",
    className = "",
    ...props
}) {
    return (
        <div
            {...props}
            className={`dd-edge-feather ${className}`}
            data-edge={edge}
            data-position={position}
            data-visible={visible ? "" : undefined}
            aria-hidden="true"
        />
    );
}
