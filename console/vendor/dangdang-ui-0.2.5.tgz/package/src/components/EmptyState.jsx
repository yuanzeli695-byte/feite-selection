import Button from "./Button.jsx";
import { cn } from "../utils/classNames.js";

export default function EmptyState({
    icon,
    title = "暂无内容",
    description,
    action,
    actionLabel,
    onAction,
    compact = false,
    className = "",
    children,
    ...props
}) {
    return (
        <div {...props} className={cn("dd-empty-state", compact && "dd-empty-state--compact", className)}>
            <div className="dd-empty-state__icon" aria-hidden="true">
                {icon || (
                    <svg viewBox="0 0 48 48">
                        <rect x="8" y="10" width="32" height="28" rx="8" />
                        <path d="M16 20h16M16 27h10" />
                    </svg>
                )}
            </div>
            <h3>{title}</h3>
            {(description || children) && <p>{description || children}</p>}
            {action || (actionLabel && <Button size="sm" variant="secondary" onClick={onAction}>{actionLabel}</Button>)}
        </div>
    );
}
