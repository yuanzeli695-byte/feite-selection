export function optionTabStopIndex(options, currentValue, groupDisabled = false) {
    if (groupDisabled) return -1;
    const selectedIndex = options.findIndex(option => option.value === currentValue && !option.disabled);
    if (selectedIndex >= 0) return selectedIndex;
    return options.findIndex(option => !option.disabled);
}

export function optionNavigationIndex(options, currentIndex, key, groupDisabled = false, vertical = false) {
    if (groupDisabled) return -1;

    const enabledIndexes = options.reduce((indexes, option, index) => {
        if (!option.disabled) indexes.push(index);
        return indexes;
    }, []);
    if (!enabledIndexes.length) return -1;
    if (key === "Home") return enabledIndexes[0];
    if (key === "End") return enabledIndexes[enabledIndexes.length - 1];

    const step = key === "ArrowRight" || (vertical && key === "ArrowDown")
        ? 1
        : key === "ArrowLeft" || (vertical && key === "ArrowUp")
            ? -1
            : 0;
    if (!step) return -1;

    const currentPosition = enabledIndexes.indexOf(currentIndex);
    if (currentPosition < 0) return step > 0 ? enabledIndexes[0] : enabledIndexes[enabledIndexes.length - 1];
    return enabledIndexes[(currentPosition + step + enabledIndexes.length) % enabledIndexes.length];
}
