export const TOAST_EVENT = "app-toast";
export const TOAST_DISMISS_EVENT = "app-toast-dismiss-all";

const TOAST_TYPES = new Set(["success", "error", "warning", "info"]);

function defaultTarget() {
    return typeof window !== "undefined" ? window : null;
}

function createEvent(type, detail, target) {
    const EventConstructor = target?.CustomEvent || globalThis.CustomEvent;
    return typeof EventConstructor === "function"
        ? new EventConstructor(type, { detail })
        : { type, detail };
}

function createId() {
    if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
    return `dd-toast-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function createToastDetail(message, type = "success", options = {}) {
    const normalizedType = TOAST_TYPES.has(type) ? type : "success";
    const duration = Number(options.duration);
    return {
        id: options.id || createId(),
        message: message instanceof Error ? message.message : String(message ?? ""),
        type: normalizedType,
        duration: Number.isFinite(duration) && duration >= 0 ? duration : 2600
    };
}

export function notify(message, type = "success", options = {}) {
    const target = options.target || defaultTarget();
    const detail = createToastDetail(message, type, options);
    target?.dispatchEvent?.(createEvent(TOAST_EVENT, detail, target));
    return detail.id;
}

export function dismissToasts(options = {}) {
    const target = options.target || defaultTarget();
    target?.dispatchEvent?.(createEvent(TOAST_DISMISS_EVENT, undefined, target));
}
