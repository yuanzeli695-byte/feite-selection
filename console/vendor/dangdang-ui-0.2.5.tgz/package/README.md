# @dangdang/ui

DangDang Studio 的内部 React 组件库。当前 `0.2.5` 面向 React 18/19 与 Vite 项目，默认提供 DangDang 视觉风格，并允许通过语义 Token 调整主题。

`0.2.5` 将 DangDangStudioCatFoodPrj 的页面滚动条沉淀为公共样式，支持完整样式、轻量 Studio 样式和独立 `scrollbars.css` 三种接入方式。

## 安装

在当前仓库中使用本地包：

```bash
npm install ../packages/dangdang-ui
```

后续接入私有 npm 源时，包名保持为：

```bash
npm install @dangdang/ui
```

## 基础使用

```jsx
import {
  Button,
  DangdangUIProvider,
  Modal,
  ModalCloseButton,
  Toast,
  notify,
} from "@dangdang/ui";
import "@dangdang/ui/styles.css";

export default function App() {
  return (
    <DangdangUIProvider
      theme="light"
      accentColor="#2563eb"
      radiusScale={1}
      glassStrength={1}
    >
      <Button onClick={() => notify("已保存")}>保存</Button>
      <Toast />
    </DangdangUIProvider>
  );
}
```

应用入口需要显式引入一次组件库样式：

```js
import "@dangdang/ui/styles.css";
```

只需要页面滚动条时可单独引入：

```js
import "@dangdang/ui/scrollbars.css";
```

## 主题定制

```jsx
<DangdangUIProvider
  theme="system"
  accentColor="#7c3aed"
  darkAccentColor="#c4b5fd"
  radiusScale={1.15}
  glassStrength={0.8}
  tokens={{
    surfaceRaised: "rgba(255,255,255,.88)",
    "--brand-focus": "#f97316",
  }}
>
  {children}
</DangdangUIProvider>
```

`tokens` 的驼峰键会转换成 `--dd-*` CSS 变量；已经以 `--` 开头的键会原样保留。

## 组件目录

### 主题与操作

- `DangdangUIProvider` / `DangdangThemeBridge`
- `Button` / `IconButton`

### 表单

- `FormField`
- `Input` / `Textarea` / `Select`
- `Checkbox` / `Radio` / `Switch`
- `Slider`

### 导航与布局

- `SegmentedControl` / `Tabs` / `Pagination`
- `Sidebar` / `SidebarHeader` / `SidebarGroup` / `SidebarItem` / `SidebarFooter`
- `Card` 及其 Header、Title、Description、Content、Footer 子组件
- `Divider` / `BottomBar` / `SearchPill` / `EdgeFeather`

### 反馈与展示

- `Modal` / `ModalCloseButton`
- `Toast` / `notify` / `dismissToasts`
- `Alert` / `Progress` / `Spinner` / `Skeleton` / `EmptyState` / `Tooltip`
- `Badge` / `Avatar` / `AvatarGroup` / `StatCard`
- `Table` 及其 Head、Body、Row、Header、Cell 子组件
- `RefreshIconButton`

`Modal` 保留焦点圈定、Esc 关闭、遮罩关闭、关闭动画和 Portal，并在弹窗完整卸载前锁定页面滚动；`Toast` 兼容 DangDang Studio 原有的 `app-toast` 与 `app-toast-dismiss-all` 事件。`Slider`、`SegmentedControl` 和 `Sidebar` 已作为正式公共组件导出，不再只存在于展示页样式中。

`SidebarItem` 默认保持主站同款单行条目，只有显式传入 `multiline` 才展示 `description`；`BottomBar` 默认是无额外外壳的控件行，需要整体玻璃胶囊时传入 `glass`。`EdgeFeather` 支持顶部/底部和视口固定/容器定位，页面外壳可按需挂入 Portal。样式入口同时提供 CatFood 同款页面滚动条，以及 `.dd-scrollbar`、`.dd-scrollbar--stable`、`.dd-scrollbar--hidden` 三个工具类。

## TypeScript 与键盘操作

- 根入口、`@dangdang/ui/studio` 和两个 CSS 入口都带有声明文件，无需额外安装社区类型包。
- `Tabs` 与 `SegmentedControl` 只保留一个 Tab 停靠点；左右方向键循环切换，`Home` / `End` 跳到首尾，并自动跳过禁用项。
- `SegmentedControl` 同时支持上下方向键，适配 radiogroup 的标准键盘习惯。
- `Input` 与 `Select` 点击控件外壳留白也会聚焦真实原生控件；装饰区中的按钮和链接仍保留独立交互。
- 组件作用域自动使用 `border-box`，并在系统开启“减弱动态效果”时压缩非必要动画。

```tsx
import { Tabs, type TabsProps, type ThemeMode } from "@dangdang/ui";

const theme: ThemeMode = "system";
const options = [
  { value: "overview", label: "概览" },
  { value: "settings", label: "设置" },
] as const;

const props: TabsProps<(typeof options)[number]["value"]> = {
  defaultValue: "overview",
  options,
};

<Tabs {...props} aria-label={`当前主题：${theme}`} />;
```

## 既有项目的轻量接入

已经拥有主题变量的现有项目可以只桥接亮/暗模式，不重复生成 Token：

```jsx
import { DangdangThemeBridge } from "@dangdang/ui/studio";
import "@dangdang/ui/studio.css";

<DangdangThemeBridge theme={darkMode ? "dark" : "light"}>
  {children}
</DangdangThemeBridge>
```

`@dangdang/ui/studio` 与 `studio.css` 分别提供轻量 JS 和样式入口，只包含主题桥接、Modal、刷新按钮和 Toast 等既有主站能力。新项目或需要按钮、完整表单、导航、布局、反馈与数据展示组件的项目应使用根入口、`DangdangUIProvider` 和 `styles.css`。

## 开发验证

```bash
npm install
npm run test:structure
npm run test:interaction
npm run test:types
npm run check
npm pack --dry-run
```

## 打开组件展示网页

组件库自带一个不依赖后端的交互式展示站，包含样式目录、主题实验台、完整 `0.2` 组件目录以及安装示例：

```bash
cd /Users/dangdang946/DangDangStudioPrj/packages/dangdang-ui
npm run demo
```

默认访问 `http://localhost:5177`。展示页可以实时切换浅色、夜间和系统主题，也可以调整主题色、圆角倍率与玻璃强度；表单、Slider、Sidebar、底栏、反馈、数据展示、Modal、Toast 和刷新按钮均为真实可操作组件，导航示例可直接用方向键、`Home` 和 `End` 验证。

## 兼容策略

- 当前仍是私有内部包，不承诺公开组件库级别的长期 API 稳定性。
- React 与 React DOM 是 peer dependency，宿主项目只保留一份 React。
- 组件实现不依赖 Tailwind；宿主项目可以使用任意 CSS 方案。
- 页面级模式组件会在主站完成解耦后分批加入，不把业务接口放进基础包。
