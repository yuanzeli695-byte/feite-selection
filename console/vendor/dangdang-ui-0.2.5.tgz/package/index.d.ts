import type * as React from "react";

export type ThemeMode = "light" | "dark" | "system";
export type ResolvedThemeMode = Exclude<ThemeMode, "system">;
export type ComponentSize = "sm" | "md" | "lg";
export type SemanticStatus = "success" | "error" | "warning" | "info";
export type ThemeTokenValue = string | number | null | undefined;
export type ThemeTokens = Record<string, ThemeTokenValue>;
export type ThemeCssVariables = Record<string, string>;

export interface DangdangUIContextValue {
    provided: boolean;
    theme: ResolvedThemeMode;
    requestedTheme: ThemeMode;
    cssVariables?: ThemeCssVariables;
}

export type PolymorphicComponentProps<
    Element extends React.ElementType,
    OwnProps = object
> = OwnProps & {
    as?: Element;
} & Omit<React.ComponentPropsWithoutRef<Element>, keyof OwnProps | "as">;

export interface DangdangUIProviderOwnProps {
    theme?: ThemeMode;
    accentColor?: string;
    darkAccentColor?: string;
    radiusScale?: number;
    glassStrength?: number;
    tokens?: ThemeTokens;
    children?: React.ReactNode;
}

export function DangdangUIProvider<Element extends React.ElementType = "div">(
    props: PolymorphicComponentProps<Element, DangdangUIProviderOwnProps>
): React.ReactElement | null;

export interface DangdangThemeBridgeProps {
    theme?: ResolvedThemeMode;
    cssVariables?: ThemeCssVariables;
    children?: React.ReactNode;
}

export function DangdangThemeBridge(props: DangdangThemeBridgeProps): React.ReactElement;
export function useDangdangUI(): DangdangUIContextValue;

export interface ResolveThemeTokensOptions {
    accentColor?: string;
    darkAccentColor?: string;
    radiusScale?: number;
    glassStrength?: number;
    tokens?: ThemeTokens;
}

export function normalizeTheme(value: unknown): ThemeMode;
export function normalizeHexColor(value: unknown, fallback?: string): string;
export function colorLuminance(value: string): number;
export function contrastFor(value: string): "#09090b" | "#ffffff";
export function mixHex(first: string, second: string, ratio?: number): string;
export function deriveDarkAccent(value: string): string;
export function tokenNameToCssVariable(name: unknown): string;
export function resolveThemeTokens(options?: ResolveThemeTokensOptions): ThemeCssVariables;

export const DEFAULT_THEME_TOKENS: Readonly<ThemeCssVariables>;
export const THEME_MODES: readonly ThemeMode[];

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    size?: ComponentSize;
    loading?: boolean;
    fullWidth?: boolean;
}

export function Button(props: ButtonProps): React.ReactElement;

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    label?: string;
    variant?: "glass" | "ghost" | "solid";
    size?: ComponentSize;
    loading?: boolean;
}

export function IconButton(props: IconButtonProps): React.ReactElement;

export interface FormFieldProps {
    id?: string;
    label?: React.ReactNode;
    description?: React.ReactNode;
    hint?: React.ReactNode;
    error?: React.ReactNode;
    required?: boolean;
    optionalLabel?: React.ReactNode;
    orientation?: "vertical" | "horizontal";
    className?: string;
    children?: React.ReactNode;
}

export function FormField(props: FormFieldProps): React.ReactElement;

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
    size?: ComponentSize;
    startAdornment?: React.ReactNode;
    endAdornment?: React.ReactNode;
    invalid?: boolean;
    fullWidth?: boolean;
    inputClassName?: string;
}

export const Input: React.ForwardRefExoticComponent<InputProps & React.RefAttributes<HTMLInputElement>>;

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    invalid?: boolean;
    resize?: "none" | "vertical" | "horizontal" | "both";
}

export const Textarea: React.ForwardRefExoticComponent<TextareaProps & React.RefAttributes<HTMLTextAreaElement>>;

export interface SelectOption<Value extends string | number = string> {
    value: Value;
    label: React.ReactNode;
    disabled?: boolean;
}

export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "size"> {
    options?: readonly SelectOption<string | number>[];
    placeholder?: React.ReactNode;
    invalid?: boolean;
    size?: ComponentSize;
}

export const Select: React.ForwardRefExoticComponent<SelectProps & React.RefAttributes<HTMLSelectElement>>;

export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
    label?: React.ReactNode;
    description?: React.ReactNode;
    indeterminate?: boolean;
}

export const Checkbox: React.ForwardRefExoticComponent<CheckboxProps & React.RefAttributes<HTMLInputElement>>;

export interface RadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
    label?: React.ReactNode;
    description?: React.ReactNode;
}

export const Radio: React.ForwardRefExoticComponent<RadioProps & React.RefAttributes<HTMLInputElement>>;

export interface SwitchProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onChange"> {
    checked?: boolean;
    onChange?: (checked: boolean, event: React.MouseEvent<HTMLButtonElement>) => void;
    label?: React.ReactNode;
    description?: React.ReactNode;
    size?: ComponentSize;
}

export function Switch(props: SwitchProps): React.ReactElement;

export interface SliderMark {
    value: number;
    label?: React.ReactNode;
}

export interface SliderProps extends Omit<
    React.InputHTMLAttributes<HTMLInputElement>,
    "type" | "size" | "value" | "defaultValue" | "onChange" | "min" | "max" | "step"
> {
    label?: React.ReactNode;
    value?: number;
    defaultValue?: number;
    onChange?: (value: number, event: React.ChangeEvent<HTMLInputElement>) => void;
    min?: number;
    max?: number;
    step?: number | "any";
    showValue?: boolean;
    formatValue?: (value: number) => React.ReactNode;
    marks?: readonly SliderMark[];
}

export function Slider(props: SliderProps): React.ReactElement;

export interface ChoiceOption<Value extends React.Key = string> {
    value: Value;
    label: React.ReactNode;
    disabled?: boolean;
    icon?: React.ReactNode;
    badge?: React.ReactNode;
}

export interface SegmentedControlProps<Value extends React.Key = string> extends Omit<
    React.HTMLAttributes<HTMLDivElement>,
    "defaultValue" | "onChange"
> {
    value?: Value;
    defaultValue?: Value;
    onChange?: (value: Value, event: React.MouseEvent<HTMLButtonElement> | React.KeyboardEvent<HTMLButtonElement>) => void;
    options?: readonly ChoiceOption<Value>[];
    size?: ComponentSize;
    fullWidth?: boolean;
    disabled?: boolean;
    ariaLabel?: string;
}

export function SegmentedControl<Value extends React.Key = string>(
    props: SegmentedControlProps<Value>
): React.ReactElement;

export interface TabOption<Value extends React.Key = string> extends ChoiceOption<Value> {
    controls?: string;
    id?: string;
}

export interface TabsProps<Value extends React.Key = string> extends Omit<
    React.HTMLAttributes<HTMLDivElement>,
    "defaultValue" | "onChange"
> {
    value?: Value;
    defaultValue?: Value;
    onChange?: (value: Value, event: React.MouseEvent<HTMLButtonElement> | React.KeyboardEvent<HTMLButtonElement>) => void;
    options?: readonly TabOption<Value>[];
    variant?: "underline" | "pill";
    size?: ComponentSize;
    ariaLabel?: string;
}

export function Tabs<Value extends React.Key = string>(props: TabsProps<Value>): React.ReactElement;

export interface PaginationProps {
    page?: number;
    pageCount?: number;
    total?: number;
    pageSize?: number;
    onChange?: (page: number) => void;
    siblingCount?: number;
    showEdges?: boolean;
    compact?: boolean;
    className?: string;
    ariaLabel?: string;
}

export function Pagination(props: PaginationProps): React.ReactElement;

export interface SidebarProps extends React.HTMLAttributes<HTMLElement> {
    collapsed?: boolean;
    width?: number;
    collapsedWidth?: number;
    variant?: "solid" | "flat" | "glass";
}

export function Sidebar(props: SidebarProps): React.ReactElement;

export type SidebarHeaderProps = React.HTMLAttributes<HTMLDivElement>;
export function SidebarHeader(props: SidebarHeaderProps): React.ReactElement;

export interface SidebarGroupProps extends React.HTMLAttributes<HTMLElement> {
    label?: React.ReactNode;
    action?: React.ReactNode;
}

export function SidebarGroup(props: SidebarGroupProps): React.ReactElement;

interface SidebarItemOwnProps {
    active?: boolean;
    icon?: React.ReactNode;
    label?: React.ReactNode;
    description?: React.ReactNode;
    multiline?: boolean;
    badge?: React.ReactNode;
    className?: string;
    children?: React.ReactNode;
}

export type SidebarButtonItemProps = SidebarItemOwnProps & Omit<
    React.ButtonHTMLAttributes<HTMLButtonElement>,
    keyof SidebarItemOwnProps
> & { href?: undefined };

export type SidebarLinkItemProps = SidebarItemOwnProps & Omit<
    React.AnchorHTMLAttributes<HTMLAnchorElement>,
    keyof SidebarItemOwnProps
> & { href: string };

export type SidebarItemProps = SidebarButtonItemProps | SidebarLinkItemProps;
export function SidebarItem(props: SidebarItemProps): React.ReactElement;

export type SidebarFooterProps = React.HTMLAttributes<HTMLDivElement>;
export function SidebarFooter(props: SidebarFooterProps): React.ReactElement;

export interface CardOwnProps {
    variant?: "raised" | "glass" | "muted" | "outline";
    interactive?: boolean;
    children?: React.ReactNode;
}

export function Card<Element extends React.ElementType = "div">(
    props: PolymorphicComponentProps<Element, CardOwnProps>
): React.ReactElement | null;

export type CardHeaderProps = React.HTMLAttributes<HTMLDivElement>;
export function CardHeader(props: CardHeaderProps): React.ReactElement;

export interface CardTitleOwnProps {
    children?: React.ReactNode;
}

export function CardTitle<Element extends React.ElementType = "h3">(
    props: PolymorphicComponentProps<Element, CardTitleOwnProps>
): React.ReactElement | null;

export type CardDescriptionProps = React.HTMLAttributes<HTMLParagraphElement>;
export function CardDescription(props: CardDescriptionProps): React.ReactElement;
export type CardContentProps = React.HTMLAttributes<HTMLDivElement>;
export function CardContent(props: CardContentProps): React.ReactElement;
export type CardFooterProps = React.HTMLAttributes<HTMLDivElement>;
export function CardFooter(props: CardFooterProps): React.ReactElement;

export interface DividerProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "align"> {
    label?: React.ReactNode;
    orientation?: "horizontal" | "vertical";
    align?: "start" | "center" | "end";
}

export function Divider(props: DividerProps): React.ReactElement;

export interface EdgeFeatherProps extends React.HTMLAttributes<HTMLDivElement> {
    edge?: "top" | "bottom";
    visible?: boolean;
    position?: "fixed" | "absolute";
}

export function EdgeFeather(props: EdgeFeatherProps): React.ReactElement;

export interface BottomBarProps extends React.HTMLAttributes<HTMLDivElement> {
    portal?: boolean;
    portalContainer?: Element | DocumentFragment | null;
    position?: "fixed" | "sticky" | "inline";
    align?: "start" | "center" | "end";
    glass?: boolean;
}

export function BottomBar(props: BottomBarProps): React.ReactElement | null;

export interface SearchPillValueEvent {
    target: { value: string };
    currentTarget: { value: string };
}

export type SearchPillChangeEvent = React.ChangeEvent<HTMLInputElement> | SearchPillValueEvent;

export interface SearchPillProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children" | "onChange"> {
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    value?: string;
    onChange?: (event: SearchPillChangeEvent) => void;
    onValueChange?: (value: string, event: SearchPillChangeEvent) => void;
    onSearch?: (value: string, event: React.KeyboardEvent<HTMLInputElement>) => void;
    placeholder?: string;
    label?: string;
    clearable?: boolean;
    disabled?: boolean;
    inputClassName?: string;
}

export function SearchPill(props: SearchPillProps): React.ReactElement;

export interface AlertProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
    type?: SemanticStatus;
    title?: React.ReactNode;
    description?: React.ReactNode;
    icon?: React.ReactNode | false;
    action?: React.ReactNode;
    closable?: boolean;
    onClose?: React.MouseEventHandler<HTMLButtonElement>;
}

export function Alert(props: AlertProps): React.ReactElement;

export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
    value?: number;
    max?: number;
    label?: React.ReactNode;
    showValue?: boolean;
    formatValue?: (percent: number) => React.ReactNode;
    size?: ComponentSize;
    status?: "default" | "success" | "warning" | "error";
    indeterminate?: boolean;
}

export function Progress(props: ProgressProps): React.ReactElement;

export interface SpinnerProps extends React.HTMLAttributes<HTMLSpanElement> {
    size?: ComponentSize;
    label?: string;
}

export function Spinner(props: SpinnerProps): React.ReactElement;

export interface SkeletonProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "children"> {
    width?: React.CSSProperties["width"];
    height?: React.CSSProperties["height"];
    radius?: React.CSSProperties["borderRadius"];
    variant?: "rect" | "text" | "circle";
    lines?: number;
    animated?: boolean;
}

export function Skeleton(props: SkeletonProps): React.ReactElement;

export interface EmptyStateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
    icon?: React.ReactNode;
    title?: React.ReactNode;
    description?: React.ReactNode;
    action?: React.ReactNode;
    actionLabel?: React.ReactNode;
    onAction?: React.MouseEventHandler<HTMLButtonElement>;
    compact?: boolean;
}

export function EmptyState(props: EmptyStateProps): React.ReactElement;

export interface TooltipProps {
    content?: React.ReactNode;
    placement?: "top" | "right" | "bottom" | "left";
    disabled?: boolean;
    delay?: number;
    className?: string;
    children?: React.ReactNode;
}

export function Tooltip(props: TooltipProps): React.ReactElement;

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
    variant?: "neutral" | "accent" | SemanticStatus;
    size?: ComponentSize;
    dot?: boolean;
    removable?: boolean;
    onRemove?: React.MouseEventHandler<HTMLButtonElement>;
}

export function Badge(props: BadgeProps): React.ReactElement;

export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
    src?: string;
    alt?: string;
    name?: string;
    fallback?: React.ReactNode;
    size?: ComponentSize | "xl";
    shape?: "circle" | "square";
    status?: "online" | "busy" | "away" | "offline";
}

export function Avatar(props: AvatarProps): React.ReactElement;

export interface AvatarGroupProps extends React.HTMLAttributes<HTMLDivElement> {
    max?: number;
    size?: AvatarProps["size"];
}

export function AvatarGroup(props: AvatarGroupProps): React.ReactElement;

export interface StatCardProps extends React.HTMLAttributes<HTMLDivElement> {
    label?: React.ReactNode;
    value?: React.ReactNode;
    unit?: React.ReactNode;
    delta?: React.ReactNode;
    deltaType?: BadgeProps["variant"];
    description?: React.ReactNode;
    icon?: React.ReactNode;
    sparkline?: React.ReactNode;
}

export function StatCard(props: StatCardProps): React.ReactElement;

export interface TableProps extends React.TableHTMLAttributes<HTMLTableElement> {
    wrapperClassName?: string;
}

export function Table(props: TableProps): React.ReactElement;
export type TableHeadProps = React.HTMLAttributes<HTMLTableSectionElement>;
export function TableHead(props: TableHeadProps): React.ReactElement;
export type TableBodyProps = React.HTMLAttributes<HTMLTableSectionElement>;
export function TableBody(props: TableBodyProps): React.ReactElement;

export interface TableRowProps extends React.HTMLAttributes<HTMLTableRowElement> {
    selected?: boolean;
    interactive?: boolean;
}

export function TableRow(props: TableRowProps): React.ReactElement;

export interface TableHeaderProps extends React.ThHTMLAttributes<HTMLTableCellElement> {
    align?: "left" | "center" | "right";
}

export function TableHeader(props: TableHeaderProps): React.ReactElement;

export interface TableCellProps extends React.TdHTMLAttributes<HTMLTableCellElement> {
    align?: "left" | "center" | "right";
    muted?: boolean;
}

export function TableCell(props: TableCellProps): React.ReactElement;

export interface ModalProps {
    open: boolean;
    onClose?: () => void;
    children?: React.ReactNode;
    overlayClassName?: string;
    panelClassName?: string;
    closeOnBackdrop?: boolean;
    closeOnEscape?: boolean;
    ariaLabel?: string;
    ariaLabelledBy?: string;
    portalContainer?: Element | DocumentFragment | null;
    closeDuration?: number;
}

export function Modal(props: ModalProps): React.ReactElement | null;

export type ModalCloseButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement>;
export function ModalCloseButton(props: ModalCloseButtonProps): React.ReactElement;

export interface RefreshIconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    loading?: boolean;
    sizeClassName?: string;
}

export function RefreshIconButton(props: RefreshIconButtonProps): React.ReactElement;

export interface ToastProps {
    target?: EventTarget | null;
    maxVisible?: number;
    className?: string;
}

export function Toast(props: ToastProps): React.ReactElement;

export type ToastType = SemanticStatus;

export interface ToastDetail {
    id: string;
    message: string;
    type: ToastType;
    duration: number;
}

export interface ToastOptions {
    id?: string;
    duration?: number;
    target?: EventTarget | null;
}

export const TOAST_EVENT: "app-toast";
export const TOAST_DISMISS_EVENT: "app-toast-dismiss-all";
export function createToastDetail(message: unknown, type?: ToastType, options?: ToastOptions): ToastDetail;
export function notify(message: unknown, type?: ToastType, options?: ToastOptions): string;
export function dismissToasts(options?: Pick<ToastOptions, "target">): void;
